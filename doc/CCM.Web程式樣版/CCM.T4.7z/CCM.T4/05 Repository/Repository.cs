﻿using CCM.Data;
using CCM.Domain;
using CCM.Domain.Entity;

//todo: 請修改對應的namespace
namespace CCM.Repository
{        
		             
	//mapping table name: FR_OFFIDOC_ISSUE
	public class FR_OFFIDOC_ISSUERepository : RepositoryBase<FR_OFFIDOC_ISSUEEntity>, IFR_OFFIDOC_ISSUERepository
    {
    }
			 		                               

}