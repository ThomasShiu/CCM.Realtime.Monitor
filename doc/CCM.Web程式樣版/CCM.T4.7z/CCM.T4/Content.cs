﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CCM.T4
{
    
    public static  class Content
    {
        public const string v_tablenm = "FR_OFFIDOC_ISSUE";
        public const string Add = "~/Content/Content/Images/Add.png";
    }
}
